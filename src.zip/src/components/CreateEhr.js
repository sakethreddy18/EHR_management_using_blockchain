import React, { useState, useEffect } from "react";
import record from "../build/contracts/record.json"; // Adjust the path as needed
import Web3 from "web3"; // Import Web3 here
import { useParams } from "react-router-dom";
import { v4 as uuidv4 } from "uuid";
import "../CSS/CreateEhr.css";

const CreateEhr = () => {
  const { address } = useParams(); // Retrieve account address from URL
  const [web3Instance, setWeb3Instance] = useState(null);
  const [recId] = useState("EHR" + uuidv4());
  const [formData, setFormData] = useState({
    patientName: "",
    doctorName: "",
    patientAddress: "",
    age: "",
    gender: "",
    diagnosis: "",
    prescription: "",
  });

  useEffect(() => {
    connectToMetaMask();
  }, []); // Connect to MetaMask when the component mounts

  const connectToMetaMask = async () => {
    try {
      if (window.ethereum) {
        const web3Instance = new Web3(window.ethereum);
        await window.ethereum.enable(); // Request account access
        setWeb3Instance(web3Instance);
      } else {
        console.error("MetaMask not detected. Please install MetaMask.");
      }
    } catch (error) {
      console.error("Error connecting to MetaMask:", error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const networkId = await web3Instance.eth.net.getId();
      const deployedNetwork = record.networks[networkId];
      if (!deployedNetwork) {
        throw new Error("Contract not deployed to this network");
      }

      const contract = new web3Instance.eth.Contract(
        record.abi,
        deployedNetwork.address
      );
      await contract.methods
        .createEHR(
          recId,
          formData.patientName,
          formData.doctorName,
          address, // Use account address from URL
          formData.patientAddress,
          parseInt(formData.age),
          formData.gender,
          formData.diagnosis,
          formData.prescription
        )
        .send({ from: formData.patientAddress });

      console.log("EHR created successfully.");
      // Reset the form fields
      setFormData({
        recordId: "",
        patientName: "",
        doctorName: "",
        age: "",
        gender: "",
        diagnosis: "",
        prescription: "",
      });
    } catch (error) {
      console.error("EHR creation failed:", error);
    }
  };

  return (
    <div className="createehr">
      <h2>Create Electronic Health Record</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="recordId">Record Id :</label>
          {recId}
        </div>
        <div>
          <label htmlFor="patientName">Patient Name:</label>
          <input
            type="text"
            id="patientName"
            name="patientName"
            value={formData.patientName}
            onChange={handleInputChange}
          />
        </div>
        <div>
          <label htmlFor="doctorName">Doctor Name:</label>
          <input
            type="text"
            id="doctorName"
            name="doctorName"
            value={formData.doctorName}
            onChange={handleInputChange}
          />
        </div>
        <div>
          <label htmlFor="age">Patient Address</label>
          <input
            type="text"
            id="patientAddress"
            name="patientAddress"
            value={formData.patientAddress}
            onChange={handleInputChange}
          />
        </div>
        <div>
          <label htmlFor="age">Age:</label>
          <input
            type="number"
            id="age"
            name="age"
            value={formData.age}
            onChange={handleInputChange}
          />
        </div>
        <div>
          <label htmlFor="gender">Gender:</label>
          <input
            type="text"
            id="gender"
            name="gender"
            value={formData.gender}
            onChange={handleInputChange}
          />
        </div>
        <div>
          <label htmlFor="diagnosis">Diagnosis:</label>
          <textarea
            type="textarea"
            id="diagnosis"
            name="diagnosis"
            value={formData.diagnosis}
            onChange={handleInputChange}
          ></textarea>
        </div>
        <div>
          <label htmlFor="prescription">Prescription:</label>
          <textarea
            type="text"
            id="prescription"
            name="prescription"
            value={formData.prescription}
            onChange={handleInputChange}
          ></textarea>
        </div>
        <button type="submit">Create Record</button>
      </form>
    </div>
  );
};

export default CreateEhr;
