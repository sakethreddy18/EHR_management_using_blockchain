// src/RecordViewer.js
import React, { useEffect, useState } from "react";
import Web3 from "web3";
import record from "../build/contracts/record.json"; // Replace with the correct path to your ABI JSON
import { useParams } from "react-router-dom";
import "../CSS/ContractInteraction.css";
function ContractInteraction() {
  const { address } = useParams();

  const [records, setRecords] = useState([]);

  useEffect(() => {
    async function fetchRecords() {
      if (typeof window.ethereum !== "undefined") {
        const web3 = new Web3(window.ethereum);
        try {
          await window.ethereum.enable();
          const networkId = await web3.eth.net.getId();
          const deployedNetwork = record.networks[networkId];
          const contractAddress = deployedNetwork.address;
          const recordContract = new web3.eth.Contract(
            record.abi,
            contractAddress
          );
          console.log(address);
          const fetchedRecords = await recordContract.methods
            .getRecords()
            .call({ from: address });
          console.log(address);
          console.log(fetchedRecords);
          setRecords(fetchedRecords);
          console.log(records);
        } catch (error) {
          console.error("Error:", error);
        }
      } else {
        console.error("Please install MetaMask extension.");
      }
    }

    fetchRecords();
  }, []);

  return (
    <div className="contractinteraction">
      <h1>Record Viewer</h1>
      <div>
        <h2>All Records:</h2>
        <ul>
          {records.map((record, index) => (
            <li key={index}>
              <strong>Record Id{record.recordId}</strong>
              <br />
              Patient Name: {record.patientName}
              <br />
              Doctor Name: {record.doctorName}
              <br />
              Doctor Address: {record.doctorAddress}
              <br />
              Age: {record.age}
              <br />
              Gender: {record.gender}
              <br />
              Diagnosis: {record.diagnosis}
              <br />
              Prescription: {record.prescription}
              <br />
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default ContractInteraction;
