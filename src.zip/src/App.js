import React, { useState, useEffect } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Web3 from "web3";
import PatientRegistration from "./components/PatientRegistration";
import RegistrationForm from "./components/RegistrationForm";
import LoginPage from "./components/LoginPage";
import PatientDashBoard from "./components/PatientDashBoard";
import DoctorDashBoard from "./components/DoctorDashBoard";
import CreateEhr from "./components/CreateEhr";
import LandingPage from "./components/LandingPage";
import NavBar from "./components/NavBar";
import ContractInteraction from "./components/ContractInteraction";
import RecordPermission from "./components/RecordPermission";
import DoctorPermission from "./components/DoctorPermission";
import DoctorLoginPage from "./components/DoctorLoginPage";
import PatientLogin from "./components/PatientLogin";
import DoctorRegistrationForm from "./components/DoctorRegistration";
import PatientWritePermission from "./components/PatientWritePermission";
import DoctorPermissionPage from "./components/DoctorPermissionPage";
function App() {
  const [web3, setWeb3] = useState(null);
  const [contract, setContract] = useState(null);
  const [accounts, setAccounts] = useState([]);
  const [loggedInPatient, setLoggedInPatient] = useState(false);

  useEffect(() => {
    const init = async () => {
      if (window.ethereum) {
        const web3Instance = new Web3(window.ethereum);
        try {
          await window.ethereum.enable();
          setWeb3(web3Instance);

          const fetchedAccounts = await web3Instance.eth.getAccounts();
          setAccounts(fetchedAccounts);
        } catch (error) {
          console.error("User denied access to accounts.");
        }
      } else {
        console.log("Please install MetaMask extension");
      }
    };

    init();
  }, []);

  return (
    <BrowserRouter>
      <NavBar></NavBar>
      <Routes>
        <Route path="/" element={<LandingPage></LandingPage>}></Route>
        <Route
          path="/patient/:address/writepermission"
          element={<PatientWritePermission></PatientWritePermission>}
        ></Route>
        <Route
          path="/patient_registration"
          element={<PatientRegistration></PatientRegistration>}
        ></Route>
        <Route
          path="/doctor_registration"
          element={<DoctorRegistrationForm></DoctorRegistrationForm>}
        ></Route>
        <Route
          path="/patient_login"
          element={<PatientLogin></PatientLogin>}
        ></Route>
        <Route
          path="/doctor_login"
          element={<DoctorLoginPage></DoctorLoginPage>}
        ></Route>
        <Route path="/login" element={<LoginPage />}></Route>
        <Route path="/patient/:address" element={<PatientDashBoard />}></Route>
        <Route path="/doctor/:address" element={<DoctorDashBoard />}></Route>
        <Route
          path="/doctor/:address/createehr"
          element={<CreateEhr web3={web3} />}
        ></Route>
        <Route
          path="/patient/:address/viewrecord"
          element={<ContractInteraction />}
        ></Route>
        <Route
          path="/patient/:address/permissionstab"
          element={<RecordPermission />}
        ></Route>
        <Route
          path="/doctor/:address/viewrec"
          element={<DoctorPermission />}
        ></Route>
        <Route
          path="/doctor/:address/doctorpermissionpage"
          element={<DoctorPermissionPage />}
        ></Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
